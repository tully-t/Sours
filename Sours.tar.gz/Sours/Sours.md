
how to install

how to customize

app configurations for consistent look

# Sours

Sours is an SVG icon theme for Linux. It is a recolor of [Beautyline](link) and [Candy icons](link), with [Sweet folders](link) and substantial original artwork.

Features:

- Tasty gradients
- Rounded lines
- Uplit, like LED indicators
- Techy gaps
- Color-coordinated: files match their app or directory (with some exceptions)

Preview image

## Installation

- place in local/share/icons or use gui in system settings

- right click -> properties -> select icon to set symbolic icon in Dolphin

## Customization

- change name
- change color in kate (phenomenon of color changing in preview/inkscape but not actually changing)
- change gradient direction in inkscape

## Notes
The conversion of Beautyline and Candy into Sours is not entirely complete. Please open an issue if you notice where this process could be accelerated.

## Contributing
Icon themes are inevitably a work in progress. Please open an issue if you notice any missing or broken icons, or to make an icon request.

## Acknowledgements
As noted in the intro, this theme is based on [Beautyline](https://store.kde.org/p/1425426) icons by [sajjad606](https://store.kde.org/u/sajjad606) and [Candy](https://github.com/EliverLara/candy-icons) icons by [EliverLara](https://github.com/EliverLara), and incorporates EliverLara's [Sweet folders](https://github.com/EliverLara/Sweet-folders) as well.

